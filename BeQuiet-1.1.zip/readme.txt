# BeQuiet
Minecraft resource pack that makes certain sounds less loud.

Sounds included in v1.0:
- Wither spawn & death
- Ender Dragon death & growls
- Endermen death

- Minecart sounds

- Thunder sounds
